package com.example.randomride;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback{

    private GoogleMap mMap;
    public float distance;
    public LatLng firstCoord, secondCoord;
    public LatLng currentCoord, addressCoord, coord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        distance = 0;

        //LatLng home = getLocationFromAddress(this,"232 Wilson Street Marlborough Massachusetts");
        //LatLng home = new LatLng(42.355080, -71.510050);
        firstCoord = coord;
        mMap.addMarker(new MarkerOptions().position(coord).title("Location Marker"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(coord, 13));
        PolylineOptions polyline = new PolylineOptions();
        polyline.add(coord);
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                polyline.add(latLng);
                secondCoord = latLng;
                float[] results = new float[1];
                Location.distanceBetween(firstCoord.latitude, firstCoord.longitude,
                        secondCoord.latitude, secondCoord.longitude, results);
                distance += results[0];
                //mMap.clear();
                mMap.addPolyline(polyline);
                firstCoord = secondCoord;
                mMap.addMarker(new MarkerOptions().position(firstCoord).title(String.valueOf(distance*0.000621371192f)));
            }
        });

    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (Exception ex) {

            ex.printStackTrace();
        }

        return p1;
    }
    public void getCurrentLocation(){
        TextView wait;
        wait = findViewById(R.id.wait);
        LocationManager locationManager;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if(ContextCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
            @Override

            public void onLocationChanged(@NonNull Location location) {
                currentCoord = new LatLng(location.getLatitude(), location.getLongitude());
                wait.setText("Current location set");
            }
        });
    }


    public void map(View map){
        setContentView(R.layout.activity_maps);
        coord = currentCoord;
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    public void address_map(View address_map){
        coord = addressCoord;
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    public void choose_start(View chooose_start){
        ImageView search;
        TextView temp;
        EditText searchbar;
        setContentView(R.layout.choose_start);
        search = findViewById(R.id.search);
        temp = findViewById(R.id.temp);
        searchbar = findViewById(R.id.searchbar);
        getCurrentLocation();
        search.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String addressCoords = searchbar.getText().toString().trim();
                temp.setText(addressCoords);
                addressCoord = getLocationFromAddress(getApplicationContext(), addressCoords);
            }
        });
    }
}